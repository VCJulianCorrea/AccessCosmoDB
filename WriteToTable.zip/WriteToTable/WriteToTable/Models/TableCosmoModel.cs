﻿using Azure;
using Azure.Data.Tables;

namespace WriteToTable.Models
{
    public class TableCosmoModel
    {
        public record Product : ITableEntity
        {
            public required string RowKey { get; set; }

            public required string PartitionKey { get; set; }

            public required string Name { get; set; }

            public required int Quantity { get; set; }

            public required decimal Price { get; set; }

            public required bool Clearance { get; set; }

            public ETag ETag { get; set; } = ETag.All;

            public DateTimeOffset? Timestamp { get; set; }
        };
        string category = "gear-surf-surfboards";

        AsyncPageable<Product> results = client.QueryAsync<Product>(
            product => product.PartitionKey == category
        );
        List<Product> entities = new();
        await foreach (Product product in results)
{
    entities.Add(product);
}
}
}
