using Azure;
using Azure.Data.Tables;
using Azure.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WriteToTable.Models;
using static WriteToTable.Models.TableCosmoModel;

namespace WriteToTable.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        DefaultAzureCredential credential = new();

        TableServiceClient serviceClient = new(
            endpoint: new Uri("<azure-cosmos-db-table-account-endpoint>"),
            credential
        );
        TableClient client = serviceClient.GetTableClient(
    tableName: "<azure-cosmos-db-table-name>"
);

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        Product entity = new()
        {
            RowKey = "aaaaaaaa-0000-1111-2222-bbbbbbbbbbbb",
            PartitionKey = "gear-surf-surfboards",
            Name = "Surfboard",
            Quantity = 10,
            Price = 300.00m,
            Clearance = true
        };

        Response response = await client.UpsertEntityAsync<Product>(
            entity: entity,
            mode: TableUpdateMode.Replace
        );
        Response<Product> response = await client.GetEntityAsync<Product>(
    rowKey: "aaaaaaaa-0000-1111-2222-bbbbbbbbbbbb",
    partitionKey: "gear-surf-surfboards"
);
    }
}
